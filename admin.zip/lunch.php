<!DOCTYPE html>
<html>
	<head>
		<link rel="stylesheet" href="stylel1.css">
	</head>
	<body>
		<div class="container">
			<div class="box">
				<div class="imgbox">
					<a href="customer_info.php"><img src="picture/l1.jpg" style="width:1200px; min-height:150px;"></a>
				</div>
				<div class="details">
					<div class="content">
					<h2>150 TK.<h2>
					</div>
				</div>
			</div>
			<div class="box">
				<div class="imgbox">
						<a href="customer_info.php"><img src="picture/l2.jpg" style="width:1200px; min-height:300px;"></a>
					</div>
					<div class="details">
						<div class="content">
						<h2>150 TK.<h2>
						</div>
					</div>
				</div>
			<div class="box">
				<div class="imgbox">
					<a href="customer_info.php"><img src="picture/l3.jpg" style="width:1200px; min-height:300px;"></a>
				</div>
				<div class="details">
					<div class="content">
					<h2>150 TK.<h2>
					</div>
				</div>
			</div>
			<div class="box">
				<div class="imgbox">
					<a href="customer_info.php"><img src="picture/l4.jpg" style="width:1200px; min-height:300px;"></a>
				</div>
				<div class="details">
					<div class="content">
					<h2>150 TK.<h2>
					</div>
				</div>
			</div>
			<div class="box">
				<div class="imgbox">
					<a href="customer_info.php"><img src="picture/l5.jpg" style="width:1200px; min-height:300px;"></a>
				</div>
				<div class="details">
					<div class="content">
					<h2>150 TK.<h2>
					</div>
				</div>
			</div>
			<div class="box">
				<div class="imgbox">
					<a href="customer_info.php"><img src="picture/l6.jpg" style="width:1200px; min-height:300px;"></a>
				</div>
				<div class="details">
					<div class="content">
					<h2>150 TK.<h2>
					</div>
				</div>
			</div>
		</div>
	</body>
</html>