<!DOCTYPE html>
<html>
	<head>
		<link rel="stylesheet" href="styleb1.css">
	</head>
	<body>
		<div class="container">
			<div class="box">
				<div class="imgbox">
					<a href="customer_info.php"><img src="picture/b5.jpg" style="width:1200px; min-height:300px;"></a>
				</div>
				<div class="details">
					<div class="content">
					<h2>150 TK.<h2>
					</div>
				</div>
			</div>
			<div class="box">
				<div class="imgbox">
						<a href="customer_info.php"><img src="picture/b3.jpg" style="width:1200px; min-height:300px;"></a>
					</div>
					<div class="details">
						<div class="content">
						<h2>150 TK.<h2>
						</div>
					</div>
				</div>
			<div class="box">
				<div class="imgbox">
					<a href="customer_info.php"><img src="picture/b2.jpeg" style="width:1200px; min-height:300px;"></a>
				</div>
				<div class="details">
					<div class="content">
					<h2>150 TK.<h2>
					</div>
				</div>
			</div>
			<div class="box">
				<div class="imgbox">
					<a href="customer_info.php"><img src="picture/b4.jpg" style="width:1200px; min-height:300px;"></a>
				</div>
				<div class="details">
					<div class="content">
					<h2>150 TK.<h2>
					</div>
				</div>
			</div>
			<div class="box">
				<div class="imgbox">
					<a href="customer_info.php"><img src="picture/b6.jpg" style="width:1200px; min-height:300px;"></a>
				</div>
				<div class="details">
					<div class="content">
					<h2>150 TK.<h2>
					</div>
				</div>
			</div>
			<div class="box">
				<div class="imgbox">
					<a href="customer_info.php"><img src="picture/breakfast.jpeg" style="width:1200px; min-height:300px;"></a>
				</div>
				<div class="details">
					<div class="content">
					<h2>150 TK.<h2>
					</div>
				</div>
			</div>
		</div>
	</body>
</html>