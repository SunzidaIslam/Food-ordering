<header>
<center><img src="picture/1.jpg" ></center><br/>
<center>
	<a href="breakfast.php"><button class="button">Breakfast</button></a>
	<a href="lunch.php"><button class="button">Lunch</button></a>
	<a href="snacks.php"><button class="button">Snacks</button></a>
	<a href="dinner.php"><button class="button">Dinner</button></a>
	<a href="home.php"><button class="button_back">Back</button></a>
</center>
</header>

<style>
.button{
	background-color:yellow;
	border:none;
	color:blue;
	padding:20px;
	text-align:center;
	text-decoration:none;
	display: inline-block;
	margin:4px 2px;
	cursor:pointer;
	border-radius:80px;
	width:20%;
	align-item:center;
	font-size:1.2rem;
	font-family:Arial;
	
	
}
.button_back{
	background-color:yellow;
	border:none;
	color:red;
	padding:20px;
	text-align:center;
	text-decoration:none;
	display: inline-block;
	margin:4px 2px;
	cursor:pointer;
	border-radius:80px;
	width:20%;
	align-item:center;
	font-size:1.4rem;
	font-family:Arial;
	
	
}

</style>