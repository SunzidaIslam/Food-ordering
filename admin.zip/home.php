<!DOCTYPE html>
<html>
<head>
	<title> Food Bank </title>
	<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
	<header>
	<div class="main">
		<ul>
			<li class="active"><a href="#">Home</a></li>
			<li><a href="food_item.php">Food Item</a></li>
			<li><a href="special_item.php">Special Item</a></li>
			<li><a href="#">About</a></li>
			<li><a href="contact.php">Contact</a></li>
			<li><a href="admin_login.php">Admin</a></li>
		</ul>
		</div>
		<div class="title">
		<h1>WELCOME TO FOOD BANK</h1>
		</div>
	</header>
</body>
</html>

