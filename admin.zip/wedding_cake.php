<!DOCTYPE html>
<html>
	<head>
		<link rel="stylesheet" href="style_wedding.css">
	</head>
	<body>
		<div class="container">
			<div class="box">
				<div class="imgbox">
					<a href="customer_info.php"><img src="picture/wedpic1.jpg" style="width:1200px; min-height:250px;"></a>
				</div>
				<div class="details">
					<div class="content">
					<h2>150 TK.<h2>
					</div>
				</div>
			</div>
			<div class="box">
				<div class="imgbox">
						<a href="customer_info.php"><img src="picture/wedpic2.jpg" style="width:1200px; min-height:300px;"></a>
					</div>
					<div class="details">
						<div class="content">
						<h2>150 TK.<h2>
						</div>
					</div>
				</div>
			<div class="box">
				<div class="imgbox">
					<a href="customer_info.php"><img src="picture/10.jpg" style="width:1200px; min-height:300px;"></a>
				</div>
				<div class="details">
					<div class="content">
					<h2>150 TK.<h2>
					</div>
				</div>
			</div>
			
		</div>
	</body>
</html>