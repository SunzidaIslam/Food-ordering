<header>
<center><img src="picture/sweet pic.jpg" ></center><br/>
<center>
	<a href="Birthday_cake.php"><button class="button">Birthday Cake</button></a>
	<a href="wedding_cake.php"><button class="button">Wedding Cake</button></a>
	<a href="gramin_pitha.php"><button class="button">Gramin Pitha</button></a>	
	<a href="sweet.php"><button class="button">Delicious Sweet</button></a>
	<a href="home.php"><button class=" Back_button">Back</button></a>
	
	
	
</center>
</header>

<style>
.button{
	background-color:yellow;
	border:none;
	color:blue;
	padding:20px;
	text-align:center;
	text-decoration:none;
	display: inline-block;
	margin:4px 2px;
	cursor:pointer;
	border-radius:80px;
	width:20%;
	align-item:center;
	font-size:1.2rem;
	font-family:Arial;
	
	
}
img{
	margin:0px;
	padding:40px;
	heigth:350px;
	width:650px;
}
.Back_button{
	background-color:yellow;
	border:none;
	color:red;
	padding:20px;
	text-align:center;
	text-decoration:none;
	display: inline-block;
	margin:4px 2px;
	cursor:pointer;
	border-radius:80px;
	width:20%;
	align-item:center;
	font-size:1.4rem;
	font-family:Arial;
}

</style>