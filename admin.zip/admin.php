<?php session_start();
  if(!isset($_SESSION['id_number'])){
    header('location:admin_login.php');
  }
  ?>

<?php
 header("Access-Control-Allow-Origin: *");
/*session_start();
if(!isset($_SESSION['email'])){
	header('location:login.php');
}*/
include_once 'Crud.php';

$crud = new Crud();

$query = "Select * from info order by id DESC";

$result = $crud->getData($query);

?>
<center><img src="picture/food bank.jpg" style="width:300px;height:300px;"></center>
<center><h1><b>FOOD BANK</b></h1></center>



<center><table border="1" class="table">

	<tr>
		<td> First Name </td>
		<td> Last Name </td>
		<td> Mobile Number </td>
		<td> Email </td>
		<td> Address </td>
		<td> Date </td>

	</tr>
	<?php

	 foreach($result as $key=>$res){
		 echo "<tr >";
		 echo "<td>".$res['First_Name']."</td>";
		 echo "<td>".$res['Last_Name']."</td>";
		 echo "<td>".$res['Mobile_Number']."</td>";
		 echo "<td>".$res['Email']."</td>";
		 echo "<td>".$res['Address']."</td>";
		 echo "<td>".$res['Date']."</td>";

		  echo "<td> <a href='edit_book.php?id=$res[id]'>Edit</a> | 
               <a href='book_delete.php?id=$res[id]'>Delete</a></td>";
               echo "</tr>";
	 }
	 ?>
</table></center><br/>
<center><a href="home.php"><button class="button">Back</button></a></center>


<style>
	.table{
		width: 100%;
		background color: : #717171;
		font-size: 18px;
		font-family: 'Josefin Sans';
	}

.button{
  background-color:blue;
  border: none;
  color: white;
  padding: 20px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  margin: 4px 2px;
  cursor: pointer;
  border-radius: 10px;
  width: 20%;
  align-items: center;
  font-size: 1.2rem;
  font-family: Century Gothic;

}
.button:hover {
  opacity: 1;
}


</style>