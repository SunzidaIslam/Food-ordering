body{
	margin:0;
	padding:0;
	font-family: sans-serif;
	
}
.container{
	width:1200px;
	min-height:500px;
	background:#fff;
	margin: 70px auto;
	display: flex;
	flex-direction:row;
	flex-wrap: wrap;
}
.container .box{
	position:relative;
	width: 300px;
	height:300px;
	background:#ff0;
	margin:10px;
	box-sizing: border-box;
	display: inline-block;
	
	
}
.container .box .imgbox{
	position:relative;
	overflow:hidden;
}
.container .box .imgbox a img{
	max-width:100%;
	max-height:100%;
	transform: transform 2s;
}
.container .box:hover .imgbox a img{
	transform: scale(2.5);
	
}
.container .box .details{
	position:absolute;
	top:10px;
	left:10px;
	bottom:10px;
	right:10px;
	background: rgba(0,0,0,.8);
	transform: scaleY(0);
	transition: transform .5s;
	
}
.container .box:hover .details{
	transform: scaleY(1);
}
.container .box .details .content{	
	position:absolute;
	top:50%;
	transform: translateY(-50%);
	text-align: center;
	padding:15px;
	color:#fff;
}
.container .box .details .content{
	margin:0;
	padding:0;
	font-size:20px;
	color:#ff0;
	
}
	