<!DOCTYPE html>
<html>
	<head>
		<link rel="stylesheet" href="styles1.css">
	</head>
	<body>
		<div class="container">
			<div class="box">
				<div class="imgbox">
					<a href="customer_info.php"><img src="picture/birthday cake 3.jpg" style="width:1200px; min-height:150px;"></a>
				</div>
				<div class="details">
					<div class="content">
					<h2>150 TK.<h2>
					</div>
				</div>
			</div>
			<div class="box">
				<div class="imgbox">
						<a href="customer_info.php"><img src="picture/birthday cake 4.jpg" style="width:1200px; min-height:300px;"></a>
					</div>
					<div class="details">
						<div class="content">
						<h2>150 TK.<h2>
						</div>
					</div>
				</div>
			<div class="box">
				<div class="imgbox">
					<a href="customer_info.php"><img src="picture/birthday cake 5.jpg" style="width:1200px; min-height:300px;"></a>
				</div>
				<div class="details">
					<div class="content">
					<h2>150 TK.<h2>
					</div>
				</div>
			</div>
			<div class="box">
				<div class="imgbox">
					<a href="customer_info.php"><img src="picture/cakee.jpg" style="width:1200px; min-height:300px;"></a>
				</div>
				<div class="details">
					<div class="content">
					<h2>150 TK.<h2>
					</div>
				</div>
			</div>
			<div class="box">
				<div class="imgbox">
					<a href="customer_info.php"><img src="picture/birthday cake 1.jpg" style="width:1200px; min-height:300px;"></a>
				</div>
				<div class="details">
					<div class="content">
					<h2>150 TK.<h2>
					</div>
				</div>
			</div>
			<div class="box">
				<div class="imgbox">
					<a href="customer_info.php"><img src="picture/birthday cake 2.jpg" style="width:1200px; min-height:300px;"></a>
				</div>
				<div class="details">
					<div class="content">
					<h2>150 TK.<h2>
					</div>
				</div>
			</div>
		</div>
	</body>
</html>