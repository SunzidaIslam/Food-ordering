<!DOCTYPE html>
<html>
<head>
	<link rel="stylesheet" href="style12.css">
</head>

<body>
	<div class="contact">
		<h1>Contact Us</h1>
		<div class="txtb">
			<label>Full Name</label>
			<input type="text" name="" value="" placeholder="Enter your name">
		</div>
		<div class="txtb">
			<label>Email</label>
			<input type="email" name="" value="" placeholder="Enter your name">
		</div>
		<div class="txtb">
			<label>Message</label>
			<input type="text" name="" value="" placeholder="Enter your message">
			<textarea></textarea>
		</div>
		<a class="btn">Send</a>
	</div>
</body>
</html>